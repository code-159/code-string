#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "list.h"

//插入节点用     list_add(&(new_node->list),&(head_node->list))     尾插     函数

/*小个结构体 
struct list_head {
	struct list_head *next, *prev;
};
*/

/*
大个结构体的地址 = (大个结构体的名字 *)（（char *）小个结构体的地址-(unsigned long)&(((大个结构体的名字 *)0)->小个结构体的名字)）//长度
*/	

typedef struct skin_manager_node{
	char name[256];
	char image_path[256];
	int price;
	int rem_number;
	struct list_head list;
}list_t,*plist;


//创建节点
//利用INIT_LIST_HEAD(ptr)，ptr中两个指针prev和next都指向自己
list_t *request_and_init_list_node()
{
	list_t *node=(list_t *)malloc(sizeof(list_t));
	if(node==NULL)
	{
		perror("request list node error\n");
		return NULL;
	}
	
	//创建两个指向自己的指针
	INIT_LIST_HEAD(&(node->list)); //因为该函数是操作小结构体的，所以要取node指向list的地址
	return node;
}

//打印
void display_list_node(struct list_head *head)
{
	struct list_head *pos;//小个结构体类型
	list_t *data_ptr;
	
	
	list_for_each(pos, head)//for的遍历，pos里会实时存放遍历到的节点的地址
	{
		data_ptr = list_entry(pos, list_t, list);//通过小个结构体获取大个结构体的地址
												//(list_entry(小个结构体地址，大个结构体名字，小个结构体在大个结构体里面的名字))
		
		printf("皮肤名字：%s,皮肤价格：%d, 皮肤剩余量：%d\n", data_ptr->name, data_ptr->price, data_ptr->rem_number);
		
	}
	
	printf("\n");
}

//移除一个
int remove_list_node(struct list_head *head, const char *rm_member_name)
{
	
	list_t *pos, *n;
	
	if(list_empty(head))
	{
		fprintf(stderr, "已经没有该皮肤了\n");
		return -1;
	}
	
	
	list_for_each_entry_safe(pos, n, head, list)
	{
		if(strcmp(pos->name, rm_member_name) == 0)
		{
			printf("free %s\n", pos->name);
			list_del(&(pos->list));
			free(pos);
			break;
		}
	}
	
	if(pos->list.next == head)
	{
		printf("已经没有图片了\n");
		return -1;
	}
	
	return 0;
}

//释放内存
int remove_and_free_list(struct list_head *head)
{
	/*
	struct list_head *pos, *n;
	list_t *rm_node;
	*/
	
	list_t *pos, *n;
#if 0
	list_for_each_safe( pos, n, head)
	{
		/*
		rm_node = list_entry(pos, list_t, list);
		printf("free %d\n", rm_node->data);
		list_del(pos);
		free(rm_node);
		*/
		
		list_del(pos);
		free(list_entry(pos, list_t, list));
	}
#else
	
	list_for_each_entry_safe(pos, n, head, list)
	{
		printf("free %s\n", pos->name);
		free(pos);
	}
#endif

	free(list_entry(head, list_t, list));
}


//函数功能：冒泡法排序节点
void kernel_list_bubling(struct list_head *head)
{
	struct list_head *pos, *ptr;
	struct list_head *next;
	struct list_head *end_flag = head;
	
	
	list_for_each(ptr, head)//从第一个节点遍历到最后一个节点的次数作为循环的次数
	{
		list_for_each(pos, head)//遍历从第一个节点到最后一个节点的过程
		{
			
			next = pos->next;//提前记录一下pos的下一个节点的位置，只是为了方便跟防止我们直接用pos->next这种相对位置的不确定性
			
			if(next == end_flag)//在冒泡法当中每次循环都会比上一次减少一次判断，因为冒泡法每一次都会确定好一个最大值放到此次比较的最后面，那下一次就没有必要比较这个位置的数据了
			{
				end_flag = end_flag->prev;//每次判断结束的位置都往前移动一个节点
				
				break;
			}
			
			if(list_entry(pos, list_t, list)->price > list_entry(next, list_t, list)->price)//判断pos的数据是不是大于pos->next的数据
			{
				if(pos == ptr)//因为ptr是外层循环当中的判断依据，如果pos跟ptr值相等，pos交换了位置则会破坏外层循环的逻辑，所以我们在这里就特殊保护了ptr的值
				{	
					ptr = ptr->prev;//选择ptr的上一个作为参考点（因为这个参考点他不可能在循环当中被移动），把ptr先移动到他的上一个位置中，你pos怎么变，以后的ptr的下一个就是原本的链表的位置
				
					list_move(pos, next);//交换两个数据的位置，
				
					ptr = ptr->next;//让ptr还原回去原本链表中的位置
				}
				else
				{
					list_move(pos, next);//交换两个数据的位置
				}
				
				pos=pos->prev;//为了让pos的新位置在下次循环当中被再次调用，用于抵消list_for_each中pos=pos->next，让这个pos的数据跟下一个数据再次比较
			}
			
		}
	}
	printf("*****************************\n");
		
	display_list_node(head);
		
	printf("*****************************\n");
}



