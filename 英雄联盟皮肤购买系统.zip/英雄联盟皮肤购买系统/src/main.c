#include "button.h"

int main(void)
{
	first_lcd();//调用最初始化界面的函数
	
	return 0;
}
