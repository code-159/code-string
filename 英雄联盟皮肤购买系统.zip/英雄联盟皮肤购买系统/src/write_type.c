#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <font.h>
#include "button.h"

int write_type(unsigned int x,unsigned int y,char buf[])
{
	int lcd_fd6;
	unsigned int *lcd_fb_addr6;


	lcd_fd6 = open_lcd_device(&lcd_fb_addr6);
	if(lcd_fd6 == -1)
		return -1;

	//打开字体	
	font *f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	  
	//字体大小的设置
	fontSetSize(f,32);//16代表字体的大小
	

	//创建一个画板（点阵图)
	bitmap *bm = createBitmapWithInit(256, 32, 4,0xffffff); //32:背景长度,16：背景宽度，4：每个像素点多少个字节，0xffffff：白色底色
	
	//先将字体写到点阵图上
	fontPrint(f,bm,0,0,buf,0x00000000,0);

	//整个点阵输出到LCD屏幕上
	show_font_to_lcd(lcd_fb_addr6,x,y,bm);

	//关闭字体，关闭画板
	fontUnload(f);
	destroyBitmap(bm);

	close_lcd_device(lcd_fd6, lcd_fb_addr6);

	return 0;
}

int write_type_1(unsigned int x,unsigned int y,char buf[])
{
	int lcd_fd5;
	unsigned int *lcd_fb_addr5;


	lcd_fd5 = open_lcd_device(&lcd_fb_addr5);
	if(lcd_fd5 == -1)
		return -1;

	//打开字体	
	font *f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	  
	//字体大小的设置
	fontSetSize(f,32);//16代表字体的大小
	

	//创建一个画板（点阵图)
	bitmap *bm = createBitmapWithInit(32,32, 4,0xffffff); //32:背景长度,16：背景宽度，4：每个像素点多少个字节，0xffffff：白色底色
	
	//先将字体写到点阵图上
	fontPrint(f,bm,0,0,buf,0x00000000,0);

	//整个点阵输出到LCD屏幕上
	show_font_to_lcd(lcd_fb_addr5,x,y,bm);

	//关闭字体，关闭画板
	fontUnload(f);
	destroyBitmap(bm);

	close_lcd_device(lcd_fd5, lcd_fb_addr5);

	return 0;
}
