#include "button.h"

int open_lcd_device(unsigned int **lcd_fb_addr)
{
	int lcd_fd;
	
	lcd_fd = open("/dev/fb0", O_RDWR);
	if(lcd_fd == -1)
	{
		perror("open lcd device failed\n");
		return -1;
	}

	*lcd_fb_addr = mmap(NULL, 800*480*4, PROT_READ|PROT_WRITE, MAP_SHARED, lcd_fd, 0);
	if(*lcd_fb_addr == MAP_FAILED)
	{
		perror("map lcd freambuffer error\n");
		return -1;
	}

	return lcd_fd;
}

int close_lcd_device(int lcd_fd, unsigned int *lcd_fb_addr)
{
	
	munmap(lcd_fb_addr, 800*480*4);

	return close(lcd_fd);
}


void lcd_display_point(int x, int y, unsigned int color, unsigned int *lcd_fb_addr)
{
	*(lcd_fb_addr+800*y+x) = color;
}

