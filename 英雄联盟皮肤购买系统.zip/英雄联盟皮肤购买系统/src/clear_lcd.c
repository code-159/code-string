#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/mman.h>


//实现清屏功能，让屏幕全显示为黑色
int clear_lcd()
{
	int *ptr=NULL;
	int i,j,fd,retval;
	fd=open("/dev/fb0",O_RDWR);
	if(fd == -1)
	{
		perror("open file error");
		return -1;
	}
	//映射内存
	ptr=mmap(NULL,480*800*4,PROT_WRITE|PROT_READ,MAP_SHARED,fd,0);
	if(ptr == MAP_FAILED)
	{
		perror("map lcd freambuffer error\n");
		return -1;
	}
	for(i=0;i<480;i++)
	{
		for(j=0;j<800;j++)
		{
			*(ptr+800*i+j)=0x000000;
		}
	}
	return 0;
}
