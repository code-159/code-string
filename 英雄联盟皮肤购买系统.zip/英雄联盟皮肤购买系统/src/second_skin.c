#include "button.h"

int num_int_2 = 8;

int Second_skin(void) 
{
	clear_lcd();    //clear lcd
	int lcd_fd,lcd_fd1,lcd_fd2;
	unsigned int *lcd_fb_addr,*lcd_fb_addr1,*lcd_fb_addr2;

	lcd_fd2 = open_lcd_device(&lcd_fb_addr2);
	lcd_fd1 = open_lcd_device(&lcd_fb_addr1);
	lcd_fd = open_lcd_device(&lcd_fb_addr);
	display_jpeg_format_file("../pic/222.jpg", 60, 50, lcd_fb_addr, 0.8);	

	char buffer1[]="皮肤名称:   IG艾瑞莉娅",buffer2[]="皮肤价格:   79元",buffer3[]="皮肤剩余量: ";
	char num[256];

	sprintf(num," %d" ,num_int_2); 
	
	write_type(500,100,buffer1);
	write_type(500,200,buffer2);
	write_type(500,300,buffer3);
	write_type_1(650,300,num);
	int ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;
	
	button bt[5];

		bt[0].start_x = 0;
		bt[0].start_y = 0;
		bt[0].length = 100;
		bt[0].height = 50;
		strcpy(bt[0].touch_pic, "../pic/返回.jpg");
		strcpy(bt[0].release_pic, "../pic/返回1.jpg");


		bt[1].start_x = 720;
		bt[1].start_y = 0;
		bt[1].length = 100;
		bt[1].height = 50;
		strcpy(bt[1].touch_pic, "../pic/退出.jpg");
		strcpy(bt[1].release_pic, "../pic/退出1.jpg");


		bt[2].start_x = 520;
		bt[2].start_y = 430;
		bt[2].length = 100;
		bt[2].height = 50;
		strcpy(bt[2].touch_pic, "../pic/下一页.jpg");
		strcpy(bt[2].release_pic, "../pic/下一页1.jpg");

		
		bt[3].start_x = 400;
		bt[3].start_y = 430;
		bt[3].length = 100;
		bt[3].height = 50;
		strcpy(bt[3].touch_pic, "../pic/上一页.jpg");
		strcpy(bt[3].release_pic, "../pic/上一页1.jpg");


		bt[4].start_x = 630;
		bt[4].start_y = 422;
		bt[4].length = 150;
		bt[4].height = 58;
		strcpy(bt[4].touch_pic, "../pic/购买1.jpg");
		strcpy(bt[4].release_pic, "../pic/购买.jpg");

		
		int x,y,i,j=8;
		int ts_status;
		for(i=0;i<5;i++)
		{
			display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
		}

		while(1)
		{
			ts_status = get_touch_status(ts_fd, &x, &y);		
			switch(ts_status){
				case TS_TOUCH:
					printf("触碰的感觉\n");
					for(i=0; i<5; i++)
					{
						if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
								&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
						{
							display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
						}
					}
					break;
				case TS_RELEASE:
					printf("放手的感觉\n");
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						printf("666");
					}

					for(i=0; i<5; i++)
					{
						display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
					}
					for(i=0; i<5; i++)	
					{	
						 if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
								&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
						{
							first_lcd_return();
							break;
						}
						else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
								&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
						{
							exit_system();
							exit(1);
							break;
						}
						else if(x>=bt[2].start_x && x<= bt[2].start_x+bt[2].length 
								&& y>=bt[2].start_y &&y<=bt[2].start_y+bt[2].height)
						{
							Three_skin();
							break;
						}
						else if(x>=bt[3].start_x && x<= bt[3].start_x+bt[3].length 
								&& y>=bt[3].start_y &&y<=bt[3].start_y+bt[3].height)
						{
							Orphans_enter();
							break;
						}
						else if(x>=bt[4].start_x && x<= bt[4].start_x+bt[4].length 
								&& y>=bt[4].start_y &&y<=bt[4].start_y+bt[4].height)
						{
							display_jpeg_format_file("../pic/购买成功.jpg", 225, 150, lcd_fb_addr2, 1);
							if(num_int_2 <= 0)
							{	
								display_jpeg_format_file("../pic/库存为0.jpg", 225, 150, lcd_fb_addr, 1);
								break;
							}							
							sleep(1);
							num_int_2--;
							Second_skin();
							break;
						}	
					}
					break;
				case TS_GET_XY:
					printf("x---->%d, y---->%d\n", x, y);
					break;
				default:
					printf("touchscreen error\n");
					break;

			}

		}
		
		close_touchscreen_device(ts_fd);
		close_lcd_device(lcd_fd,lcd_fb_addr);
		close_lcd_device(lcd_fd1,lcd_fb_addr1);
		close_lcd_device(lcd_fd2,lcd_fb_addr2);

	return 0;
}

int Second_skin_m(void)
{
	clear_lcd();   //clear lcd
	int lcd_fd,lcd_fd1,lcd_add,lcd_del;
	unsigned int *lcd_fb_addr,*lcd_fb_addr1,*lcd_add_addr,*lcd_del_addr;
	
	lcd_add = open_lcd_device(&lcd_add_addr);
	lcd_del = open_lcd_device(&lcd_del_addr);
	lcd_fd1 = open_lcd_device(&lcd_fb_addr1);
	lcd_fd = open_lcd_device(&lcd_fb_addr);
	display_jpeg_format_file("../pic/222.jpg", 60, 50, lcd_fb_addr, 0.8);
	
	char buffer1[]="皮肤名称:   IG艾瑞莉娅",buffer2[]="皮肤价格:   79元",buffer3[]="皮肤剩余量: ";
	char num[256];

	sprintf(num," %d" ,num_int_2); 
	
	write_type(500,100,buffer1);
	write_type(500,200,buffer2);
	write_type(500,300,buffer3);
	write_type_1(650,300,num);

	int ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;
	
	button bt[5];

		bt[0].start_x = 0;
		bt[0].start_y = 0;
		bt[0].length = 100;
		bt[0].height = 50;
		strcpy(bt[0].touch_pic, "../pic/返回.jpg");
		strcpy(bt[0].release_pic, "../pic/返回1.jpg");


		bt[1].start_x = 630;
		bt[1].start_y = 354;
		bt[1].length = 150;
		bt[1].height = 58;
		strcpy(bt[1].touch_pic, "../pic/添加.jpg");
		strcpy(bt[1].release_pic, "../pic/添加1.jpg");


		bt[2].start_x = 520;
		bt[2].start_y = 430;
		bt[2].length = 100;
		bt[2].height = 50;
		strcpy(bt[2].touch_pic, "../pic/下一页.jpg");
		strcpy(bt[2].release_pic, "../pic/下一页1.jpg");

		
		bt[3].start_x = 400;
		bt[3].start_y = 430;
		bt[3].length = 100;
		bt[3].height = 50;
		strcpy(bt[3].touch_pic, "../pic/上一页.jpg");
		strcpy(bt[3].release_pic, "../pic/上一页1.jpg");


		bt[4].start_x = 630;
		bt[4].start_y = 422;
		bt[4].length = 150;
		bt[4].height = 58;
		strcpy(bt[4].touch_pic, "../pic/删除.jpg");
		strcpy(bt[4].release_pic, "../pic/删除1.jpg");

		
		int x,y,i;
		int ts_status;
		for(i=0;i<5;i++)
		{
			display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
		}

		while(1)
		{
			ts_status = get_touch_status(ts_fd, &x, &y);		
			switch(ts_status){
				case TS_TOUCH:
					printf("触碰的感觉\n");
					for(i=0; i<5; i++)
					{
						if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
								&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
						{
							display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
						}
					}
					break;
				case TS_RELEASE:
					printf("放手的感觉\n");
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						printf("666");
					}

					for(i=0; i<5; i++)
					{
						display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
					}
					for(i=0; i<5; i++)	
					{	
						 if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
								&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
						{
							first_lcd_return();
							break;
						}
						else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
								&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
						{	
							display_jpeg_format_file("../pic/添加库存.jpg", 225, 150, lcd_add_addr, 1);
							sleep(1);
							num_int_2++;
							Second_skin_m();
							break;
						}
						else if(x>=bt[2].start_x && x<= bt[2].start_x+bt[2].length 
								&& y>=bt[2].start_y &&y<=bt[2].start_y+bt[2].height)
						{
							Three_skin_m();
							break;
						}
						else if(x>=bt[3].start_x && x<= bt[3].start_x+bt[3].length 
								&& y>=bt[3].start_y &&y<=bt[3].start_y+bt[3].height)
						{
							Management_enter();
							break;
						}
						else if(x>=bt[4].start_x && x<= bt[4].start_x+bt[4].length 
								&& y>=bt[4].start_y &&y<=bt[4].start_y+bt[4].height)
						{
							display_jpeg_format_file("../pic/删除库存.jpg", 225, 150, lcd_del_addr, 1);
							if(num_int_2 <= 0)
							{	
								display_jpeg_format_file("../pic/库存为0.jpg", 225, 150, lcd_fb_addr, 1);
								break;
							}							
							sleep(1);
							num_int_2--;
							Second_skin_m();
							break;
						}	
					}
					break;
				case TS_GET_XY:
					printf("x---->%d, y---->%d\n", x, y);
					break;
				default:
					printf("touchscreen error\n");
					break;

			}

		}
		
		close_touchscreen_device(ts_fd);
		close_lcd_device(lcd_fd,lcd_fb_addr);
		close_lcd_device(lcd_fd1,lcd_fb_addr1);
		close_lcd_device(lcd_add,lcd_add_addr);
		close_lcd_device(lcd_del,lcd_del_addr);

	return 0;
}
