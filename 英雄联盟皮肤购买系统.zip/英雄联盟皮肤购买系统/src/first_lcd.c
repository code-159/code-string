#include "button.h"

//init panel


int exit_system(void)
{
	int lcd_fd8;
	unsigned int *lcd_fd8_addr;

	lcd_fd8 = open_lcd_device(&lcd_fd8_addr);
	
	display_jpeg_format_file("../pic/退出系统.jpg", 0, 0, lcd_fd8_addr, 1);

	close_lcd_device(lcd_fd8,lcd_fd8_addr);
	return 0;
}

int first_lcd(void)
{
	int first_lcd,second_lcd;
	
	unsigned int *lcd_fb_addr,*lcd_fb_add2;
	
	first_lcd=open_lcd_device(&lcd_fb_addr);
	second_lcd=open_lcd_device(&lcd_fb_add2);
	
	display_jpeg_format_file("../pic/安妮.jpg", 0, 0, lcd_fb_addr, 1);
	sleep(3);
	display_jpeg_format_file("../pic/开始界面.jpg",0,0,lcd_fb_add2,1);	


	int ts_fd;
	int x,y,i;
	int ts_status;


	ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;

	int lcd_fd1;
	unsigned int *lcd_fb_addr1;
	lcd_fd1 = open_lcd_device(&lcd_fb_addr1);

	button bt[2];

	bt[0].start_x = 0;
	bt[0].start_y = 410;
	bt[0].length = 300;
	bt[0].height = 55;
	strcpy(bt[0].touch_pic, "../pic/管理1.jpg");
	strcpy(bt[0].release_pic, "../pic/管理.jpg");


	bt[1].start_x = 500;
	bt[1].start_y = 410;
	bt[1].length = 300;
	bt[1].height = 55;
	strcpy(bt[1].touch_pic, "../pic/孤儿1.jpg");
	strcpy(bt[1].release_pic, "../pic/孤儿.jpg");

	for(i=0;i<2;i++)
	{
		display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
	}

	while(1)
	{
		ts_status = get_touch_status(ts_fd, &x, &y);		
		switch(ts_status){
			case TS_TOUCH:
				printf("触碰的感觉\n");
				for(i=0; i<2; i++)
				{
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
					}
				}

				break;
			case TS_RELEASE:
				printf("放手的感觉\n");
				if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
						&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
				{
					printf("666");
				}

				for(i=0; i<2; i++)
				{
					display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
				}
				for(i=0;i<2;i++)
				{
					if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
							&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
					{
						Management_enter();
						break;
					}
					else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
							&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
					{
						Orphans_enter();
						break;
					}
				}

				break;
			case TS_GET_XY:
				printf("x---->%d, y---->%d\n", x, y);
				break;
			default:
				printf("touchscreen error\n");
				break;

		}

	}
	//goto_activity(ts_fd, main_menu, bt, 5, NULL, lcd_fb_addr);
	
	
	close_lcd_device(first_lcd,lcd_fb_addr);
	close_lcd_device(second_lcd,lcd_fb_add2);
	
}

int first_lcd_return(void)
{
	int second_lcd;
	
	unsigned int *lcd_fb_add2,*lcd_fb_addr;

	second_lcd=open_lcd_device(&lcd_fb_add2);
	
	display_jpeg_format_file("../pic/开始界面.jpg",0,0,lcd_fb_add2,1);	

	int ts_fd,lcd_fd;
	int x,y,i;
	int ts_status;

	lcd_fd = open_lcd_device(&lcd_fb_addr);

	ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;

	int lcd_fd1;
	unsigned int *lcd_fb_addr1;
	lcd_fd1 = open_lcd_device(&lcd_fb_addr1);

	button bt[2];

	bt[0].start_x = 0;
	bt[0].start_y = 410;
	bt[0].length = 300;
	bt[0].height = 55;
	strcpy(bt[0].touch_pic, "../pic/管理1.jpg");
	strcpy(bt[0].release_pic, "../pic/管理.jpg");


	bt[1].start_x = 500;
	bt[1].start_y = 410;
	bt[1].length = 300;
	bt[1].height = 55;
	strcpy(bt[1].touch_pic, "../pic/孤儿1.jpg");
	strcpy(bt[1].release_pic, "../pic/孤儿.jpg");

	
	for(i=0;i<2;i++)
	{
		display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
	}
	
	while(1)
	{
		ts_status = get_touch_status(ts_fd, &x, &y);		
		switch(ts_status){
			case TS_TOUCH:
				printf("触碰的感觉\n");
				for(i=0; i<2; i++)
				{
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
					}
				}

				break;
			case TS_RELEASE:
				printf("放手的感觉\n");
				if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
						&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
				{
					printf("666");
				}

				for(i=0; i<2; i++)
				{
					display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, lcd_fb_addr, 1);
				}
				for(i=0;i<2;i++)
				{
					if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
							&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
					{
						Management_enter();
						break;
					}
					else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
							&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
					{
						Orphans_enter();
						break;
					}
				}

				break;
			case TS_GET_XY:
				printf("x---->%d, y---->%d\n", x, y);
				break;
			default:
				printf("touchscreen error\n");
				break;

		}

	}
	//goto_activity(ts_fd, main_menu, bt, 5, NULL, lcd_fb_addr);
	
	
	close_lcd_device(lcd_fd, lcd_fb_addr);
	close_lcd_device(second_lcd,lcd_fb_add2);
	
}
