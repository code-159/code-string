#include "button.h"


//一个播放的线程,播放第四个视频

void *play_video_4(void *arg)
{
	pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED , NULL);//延时退出

	system("mplayer -slave -quiet -input file=myfifo -geometry 100:0 -zoom -x 600 -y 350 ../video/444.mp4");

	pthread_exit(NULL);
}


int play_4(void)
{
	clear_lcd();//清屏

	int first_lcd,button_fd;

	unsigned int *lcd_fb_addr,*button_fb_addr;

	first_lcd = open_lcd_device(&lcd_fb_addr);
	button_fd = open_lcd_device(&button_fb_addr);

	display_jpeg_format_file("../pic/666.jpg", 0, 0, lcd_fb_addr, 1);

	int ts_fd;
	int x,y,i;
	int ts_status;

	//printf("666\n");
	int fd = open("./myfifo", O_RDWR);
	if(fd == -1)
	{
		perror("open fifo failed");
		return -1;
	}

	ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;
	//printf("fuck you\n");

	button bt[9];
	//播放列表
	bt[0].start_x = 0;
	bt[0].start_y = 0;
	bt[0].length = 100;
	bt[0].height = 350;
	strcpy(bt[0].touch_pic, "../pic/播放列表.jpg");
	strcpy(bt[0].release_pic, "../pic/播放列表.jpg");

	//快进
	bt[1].start_x = 450;
	bt[1].start_y = 430;
	bt[1].length = 50;
	bt[1].height = 50;
	strcpy(bt[1].touch_pic, "../pic/快进.jpg");
	strcpy(bt[1].release_pic, "../pic/快进.jpg");

	//快退
	bt[2].start_x = 250;
	bt[2].start_y = 430;
	bt[2].length = 50;
	bt[2].height = 50;
	strcpy(bt[2].touch_pic, "../pic/快退.jpg");
	strcpy(bt[2].release_pic, "../pic/快退.jpg");
	
	//暂停
	bt[3].start_x = 350;
	bt[3].start_y = 430;
	bt[3].length = 50;
	bt[3].height = 50;
	strcpy(bt[3].touch_pic, "../pic/暂停.jpg");
	strcpy(bt[3].release_pic, "../pic/暂停.jpg");
	
	//静音
	bt[4].start_x = 700;
	bt[4].start_y = 100;
	bt[4].length = 100;
	bt[4].height = 100;
	strcpy(bt[4].touch_pic, "../pic/静音1.jpg");
	strcpy(bt[4].release_pic, "../pic/静音1.jpg");

	//退出系统
	bt[5].start_x = 700;
	bt[5].start_y = 0;
	bt[5].length = 100;
	bt[5].height = 100;
	strcpy(bt[5].touch_pic, "../pic/退出.jpg");
	strcpy(bt[5].release_pic, "../pic/退出1.jpg");
	
	//恢复音量
	bt[6].start_x = 700;
	bt[6].start_y = 200;
	bt[6].length = 100;
	bt[6].height = 100;
	strcpy(bt[6].touch_pic, "../pic/静音.jpg");
	strcpy(bt[6].release_pic, "../pic/静音.jpg");
	printf("fuck you\n");
	
	//加音量
	bt[7].start_x = 700;
	bt[7].start_y = 300;
	bt[7].length = 100;
	bt[7].height = 90;
	strcpy(bt[7].touch_pic, "../pic/加音.jpg");
	strcpy(bt[7].release_pic, "../pic/加音.jpg");
	
	//减音量
	bt[8].start_x = 700;
	bt[8].start_y = 390;
	bt[8].length = 100;
	bt[8].height = 90;
	strcpy(bt[8].touch_pic, "../pic/减音.jpg");
	strcpy(bt[8].release_pic, "../pic/减音.jpg");
	printf("fuck you\n");
	
	for(i=0;i<9;i++)
	{
		display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
	}
	
	//创建线程，播放视频
	pthread_t tid;
	errno = pthread_create(&tid, NULL, play_video_4, NULL);
	if(errno != 0)
	{
		perror("creat thread error");
		return -1;
	}

	while(1)
	{
		ts_status = get_touch_status(ts_fd, &x, &y);		
		switch(ts_status){
			case TS_TOUCH:
				printf("触碰的感觉\n");
				for(i=0; i<9; i++)
				{
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
					}
				}
				break;
				
			case TS_RELEASE:
				printf("放手的感觉\n");
				for(i=0;i<9;i++)
				{
					if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
							&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
					{
						//调用播放列表函数
						printf("\n进入播放列表\n");
						
						close(fd);//先关闭文件描述符
						
						system("killall -9 mplayer");//杀死线程播放的视频
						play_list();//再进入播放列表的函数

						break;
					}
					
					else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
							&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
					{
						//快进
						printf("\n快进10s\n");
						
						write(fd , "seek +10\n",strlen("seek +10\n"));

						//system("echo \"seek +10\" >> myfifo\n");//这个是用system函数快进					
						break;
					}
					
					else if(x>=bt[2].start_x && x<= bt[2].start_x+bt[2].length 
							&& y>=bt[2].start_y &&y<=bt[2].start_y+bt[2].height)
					{
						//快退
						printf("\n快退10s\n");

						write(fd ,"seek -10\n", strlen("seek -10\n"));

						//system("echo \"seek -10\" >> myfifo\n");
						break;
					}

					else if(x>=bt[3].start_x && x<= bt[3].start_x+bt[3].length 
							&& y>=bt[3].start_y &&y<=bt[3].start_y+bt[3].height)
					{
						static int pause_button_flag = 0;
						//暂停
						if(pause_button_flag == 0)
						{						
							write(fd , "pause\n", strlen("pause\n"));
							//display_jpeg_format_file(bt[3].release_pic, bt[3].start_x, bt[3].start_y, button_fb_addr, 1);

							printf("\n暂停\n");

							pause_button_flag = 1;	

							break;					
						}
						
						if(pause_button_flag != 0)
						{
							write(fd , "pause\n" , strlen("pause\n"));

							//display_jpeg_format_file(bt[3].touch_pic, bt[3].start_x, bt[3].start_y, button_fb_addr, 1);

							printf("\n播放\n");							

							pause_button_flag = 0;	

							break;
						}
						break;
					}

					else if(x>=bt[4].start_x && x<= bt[4].start_x+bt[4].length 
							&& y>=bt[4].start_y &&y<=bt[4].start_y+bt[4].height)
					{
						//静音
						write(fd , "mute 1\n", strlen("mute 1\n"));

						printf("\n静音\n");

						break;
					}
					
					else if(x>=bt[5].start_x && x<= bt[5].start_x+bt[5].length 
							&& y>=bt[5].start_y &&y<=bt[5].start_y+bt[5].height)
					{
						//退出
						printf("\n退出\n");

						pthread_cancel(tid);

						system("killall -9 mplayer");

						exit_system();

						exit(0);
					}
					
					else if(x>=bt[6].start_x && x<= bt[6].start_x+bt[6].length 
							&& y>=bt[6].start_y &&y<=bt[6].start_y+bt[6].height)
					{
						//恢复音量
						write(fd , "mute 0\n", strlen("mute 0\n"));

						system("ls -l");

						printf("\n恢复音量\n");

						break;
					}
					
					else if(x>=bt[7].start_x && x<= bt[7].start_x+bt[7].length 
							&& y>=bt[7].start_y &&y<=bt[7].start_y+bt[7].height)
					{
						//音量加50
						printf("\n音量+50\n");
						
						write(fd, "volume 50\n", strlen("volume 50\n"));
					
						break;
					}
					
					else if(x>=bt[8].start_x && x<= bt[8].start_x+bt[8].length 
							&& y>=bt[8].start_y &&y<=bt[8].start_y+bt[8].height)
					{
						//音量减50
						printf("\n音量-50\n");

						write(fd, "volume -50\n", strlen("volume -50\n"));

						break;
					}
				}
				break;

			case TS_GET_XY:
				printf("x---->%d, y---->%d\n", x, y);
				break;
				
			default:
				printf("touchscreen error\n");
				break;
		}
	}
	
	close_touchscreen_device(ts_fd);

	close_lcd_device(first_lcd,lcd_fb_addr);

	close_lcd_device(button_fd,button_fb_addr);
	
	return 0;
}
