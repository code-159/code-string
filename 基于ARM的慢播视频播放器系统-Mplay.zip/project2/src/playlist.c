#include "button.h"

/*
	显示播放列表函数
	进行界面的跳转，实现效果为一共7个按钮，
	6个视频跳转按钮，实现6个视屏的跳转
	只是播放着相应的视屏内容
*/


int play_list(void)
{
	clear_lcd();//清屏

	int first_lcd,button_fd;

	unsigned int *lcd_fb_addr,*button_fb_addr;

	first_lcd = open_lcd_device(&lcd_fb_addr);
	button_fd = open_lcd_device(&button_fb_addr);

	display_jpeg_format_file("../pic/背景.jpg", 0, 0, lcd_fb_addr, 1);
	
	//打印相关视频名字
	char buf_1[]="           twice",buf_2[]="        提线木偶",buf_3[]="      momoland",buf_4[]="       Despacito",buf_5[]="      播放列表";
	write_type(100,210,buf_1);
	write_type(500,210,buf_2);
	write_type(100,420,buf_3);
	write_type(500,420,buf_4);
	write_type(25,10,buf_5);

	int ts_fd;
	int x,y,i;
	int ts_status;

	ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;
	//printf("fuck you\n");

	button bt[7];
	//twice
	bt[0].start_x = 100;
	bt[0].start_y = 80;
	bt[0].length = 200;
	bt[0].height = 120;
	strcpy(bt[0].touch_pic, "../pic/p1.jpg");
	strcpy(bt[0].release_pic, "../pic/p1.jpg");

	//提线木偶
	bt[1].start_x = 500;
	bt[1].start_y = 80;
	bt[1].length = 200;
	bt[1].height = 120;
	strcpy(bt[1].touch_pic, "../pic/p2.jpg");
	strcpy(bt[1].release_pic, "../pic/p2.jpg");

	//momoland
	bt[2].start_x = 100;
	bt[2].start_y = 280;
	bt[2].length = 200;
	bt[2].height = 120;
	strcpy(bt[2].touch_pic, "../pic/p3.jpg");
	strcpy(bt[2].release_pic, "../pic/p3.jpg");
	
	//Despacito
	bt[3].start_x = 500;
	bt[3].start_y = 280;
	bt[3].length = 200;
	bt[3].height = 120;
	strcpy(bt[3].touch_pic, "../pic/p4.jpg");
	strcpy(bt[3].release_pic, "../pic/p4.jpg");
	
	//上一页
	bt[4].start_x = 25;
	bt[4].start_y = 215;
	bt[4].length = 50;
	bt[4].height = 50;
	strcpy(bt[4].touch_pic, "../pic/上一页.jpg");
	strcpy(bt[4].release_pic, "../pic/上一页1.jpg");

	//下一页
	bt[5].start_x = 725;
	bt[5].start_y = 215;
	bt[5].length = 50;
	bt[5].height = 50;
	strcpy(bt[5].touch_pic, "../pic/下一页.jpg");
	strcpy(bt[5].release_pic, "../pic/下一页1.jpg");

	//退出系统
	bt[6].start_x = 700;
	bt[6].start_y = 0;
	bt[6].length = 100;
	bt[6].height = 100;
	strcpy(bt[6].touch_pic, "../pic/退出.jpg");
	strcpy(bt[6].release_pic, "../pic/退出1.jpg");
	
	for(i=0;i<7;i++)
	{
		display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
	}

	while(1)
	{
		ts_status = get_touch_status(ts_fd, &x, &y);		
		switch(ts_status){
			case TS_TOUCH:
				printf("触碰的感觉\n");
				for(i=0; i<7; i++)
				{
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
					}
				}
				break;
				
			case TS_RELEASE:
				printf("放手的感觉\n");
				for(i=0; i<7; i++)
				{
					display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
				}

				for(i=0;i<7;i++)
				{
					if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
							&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
					{
						//进入第一个视频
						printf("进入第一个视频：twice:what is love \n");
						
						play_1();//调用第一个视频函数
						
						break;
					}
					
					else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
							&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
					{
						//进入第二个视频
						printf("进入第二个视频：提线木偶 \n");

						play_2();//调用第二个视频函数
						
						break;
					}
					
					else if(x>=bt[2].start_x && x<= bt[2].start_x+bt[2].length 
							&& y>=bt[2].start_y &&y<=bt[2].start_y+bt[2].height)
					{
						//进入第三个视频
						printf("进入第三个视频：momoland:bboom bboom \n");
						
						play_3();//调用第三个视频函数
						
						break;
					}

					else if(x>=bt[3].start_x && x<= bt[3].start_x+bt[3].length 
							&& y>=bt[3].start_y &&y<=bt[3].start_y+bt[3].height)
					{
						//进入第四个视频
						printf("进入第四个视频：Despacito \n");
						
						play_4();//调用第四个视频函数
						
						break;
					}
					
					else if(x>=bt[4].start_x && x<= bt[4].start_x+bt[4].length 
							&& y>=bt[4].start_y &&y<=bt[4].start_y+bt[4].height)
					{
						//上一页,没有上一页直接break
						break;
					}
					
					else if(x>=bt[5].start_x && x<= bt[5].start_x+bt[5].length 
							&& y>=bt[5].start_y &&y<=bt[5].start_y+bt[5].height)
					{
						//下一页，进入下一页的函数跳转
						play_list_2();
						
						break;
					}
					
					else if(x>=bt[6].start_x && x<= bt[6].start_x+bt[6].length 
							&& y>=bt[6].start_y &&y<=bt[6].start_y+bt[6].height)
					{
						//退出系统
						printf("\n退出\n");
						
						exit_system();

						exit(0);
					}
				}
				break;

			case TS_GET_XY:
				printf("x---->%d, y---->%d\n", x, y);
				break;
				
			default:
				printf("touchscreen error\n");
				break;
		}
	}
	
	close_touchscreen_device(ts_fd);

	close_lcd_device(first_lcd,lcd_fb_addr);

	close_lcd_device(button_fd,button_fb_addr);
	
	return 0;
}

int play_list_2(void)
{
	clear_lcd();//清屏

	int first_lcd,button_fd;

	unsigned int *lcd_fb_addr,*button_fb_addr;

	first_lcd = open_lcd_device(&lcd_fb_addr);
	button_fd = open_lcd_device(&button_fb_addr);

	display_jpeg_format_file("../pic/背景.jpg", 0, 0, lcd_fb_addr, 1);
	
	//打印相关视频名字
	char buf_1[]="         忐忑不安",buf_2[]="            刺痛",buf_5[]="     播放列表 2";
	write_type(100,210,buf_1);
	write_type(500,210,buf_2);
	write_type(25,10,buf_5);

	int ts_fd;
	int x,y,i;
	int ts_status;

	ts_fd = open_touchscreen_device();
	if(ts_fd == -1)
		return -1;
	//printf("fuck you\n");

	button bt[5];
	//忐忑不安
	bt[0].start_x = 100;
	bt[0].start_y = 80;
	bt[0].length = 200;
	bt[0].height = 120;
	strcpy(bt[0].touch_pic, "../pic/p5.jpg");
	strcpy(bt[0].release_pic, "../pic/p5.jpg");

	//刺痛
	bt[1].start_x = 500;
	bt[1].start_y = 80;
	bt[1].length = 200;
	bt[1].height = 120;
	strcpy(bt[1].touch_pic, "../pic/p6.jpg");
	strcpy(bt[1].release_pic, "../pic/p6.jpg");

	//上一页
	bt[2].start_x = 25;
	bt[2].start_y = 215;
	bt[2].length = 50;
	bt[2].height = 50;
	strcpy(bt[2].touch_pic, "../pic/上一页.jpg");
	strcpy(bt[2].release_pic, "../pic/上一页1.jpg");

	//下一页
	bt[3].start_x = 725;
	bt[3].start_y = 215;
	bt[3].length = 50;
	bt[3].height = 50;
	strcpy(bt[3].touch_pic, "../pic/下一页.jpg");
	strcpy(bt[3].release_pic, "../pic/下一页1.jpg");

	//退出系统
	bt[4].start_x = 700;
	bt[4].start_y = 0;
	bt[4].length = 100;
	bt[4].height = 100;
	strcpy(bt[4].touch_pic, "../pic/退出.jpg");
	strcpy(bt[4].release_pic, "../pic/退出1.jpg");
	
	for(i=0;i<5;i++)
	{
		display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
	}

	while(1)
	{
		ts_status = get_touch_status(ts_fd, &x, &y);		
		switch(ts_status){
			case TS_TOUCH:
				printf("触碰的感觉\n");
				for(i=0; i<5; i++)
				{
					if(x>=bt[i].start_x && x<= bt[i].start_x+bt[i].length 
							&& y>=bt[i].start_y &&y<=bt[i].start_y+bt[i].height)
					{
						display_jpeg_format_file(bt[i].release_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
					}
				}
				break;
				
			case TS_RELEASE:
				printf("放手的感觉\n");
				for(i=0; i<5; i++)
				{
					display_jpeg_format_file(bt[i].touch_pic, bt[i].start_x, bt[i].start_y, button_fb_addr, 1);
				}

				for(i=0;i<5;i++)
				{
					if(x>=bt[0].start_x && x<= bt[0].start_x+bt[0].length 
							&& y>=bt[0].start_y &&y<=bt[0].start_y+bt[0].height)
					{
						//进入第一个视频
						printf("进入第一个视频：twice:what is love \n");
						
						play_5();//调用第五个视频函数
						
						break;
					}
					
					else if(x>=bt[1].start_x && x<= bt[1].start_x+bt[1].length 
							&& y>=bt[1].start_y &&y<=bt[1].start_y+bt[1].height)
					{
						//进入第二个视频
						printf("进入第二个视频：提线木偶 \n");

						play_6();//调用第六个视频函数
						
						break;
					}
					
					else if(x>=bt[2].start_x && x<= bt[2].start_x+bt[2].length 
							&& y>=bt[2].start_y &&y<=bt[2].start_y+bt[2].height)
					{
						//上一页
						printf("\n上一页 \n");
						play_list();//进入上一页也就是视频列表的函数
						
						break;
					}

					else if(x>=bt[3].start_x && x<= bt[3].start_x+bt[3].length 
							&& y>=bt[3].start_y &&y<=bt[3].start_y+bt[3].height)
					{
						//下一页
						printf("\n下一页 \n");
						break;
					}
					
					else if(x>=bt[4].start_x && x<= bt[4].start_x+bt[4].length 
							&& y>=bt[4].start_y &&y<=bt[4].start_y+bt[4].height)
					{
						//退出系统
						printf("\n退出\n");
						
						exit_system();

						exit(0);
					}
				}
				break;

			case TS_GET_XY:
				printf("x---->%d, y---->%d\n", x, y);
				break;
				
			default:
				printf("touchscreen error\n");
				break;
		}
	}
	
	close_touchscreen_device(ts_fd);

	close_lcd_device(first_lcd,lcd_fb_addr);

	close_lcd_device(button_fd,button_fb_addr);
	
	return 0;
	
}
