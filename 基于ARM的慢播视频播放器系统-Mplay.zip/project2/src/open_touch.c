#include "button.h"


int open_touchscreen_device(void)
{
	int ts_fd;

	ts_fd = open( "/dev/input/event0", O_RDONLY);
	if(ts_fd == -1)
	{
		perror("open touchscreen device error");
		return -1;
	}

	return ts_fd;
}

int close_touchscreen_device(int ts_fd)
{
	return close(ts_fd);
}
